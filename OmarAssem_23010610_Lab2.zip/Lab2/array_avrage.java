import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class array_avrage {
    public double average(int[] array) {
        if (array.length == 0) {
            return 0;
        }
        double sum = 0;
        for (int i = 0; i < array.length; i++) {
            sum += array[i];
        }
        return sum / array.length;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine().replaceAll("\\[|\\]", "");
        String[] inputsplitting =input.split(", ");
        int[] array = new int[inputsplitting.length];

        for (int i = 0; i < inputsplitting.length; i++) {
            if (inputsplitting[i].length() != 0) {
            array[i] = Integer.parseInt(inputsplitting[i]);
            }else{
                array[i] = 0;
            }
        }
        double Final_ans = new array_avrage().average(array);
        System.out.println(Final_ans);
    }
}