import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class SumAndOdd {
    public int[] sumEvenOdd(int[] array) {
        int sumOfEven = 0;
        int sumOfOdd = 0;
        for (int i = 0; i < array.length; i++) {
            if (array[i] % 2 == 0) {
                sumOfEven += array[i];
            }
            if (array[i] % 2 != 0) {
                sumOfOdd += array[i];
            }
        }
        return new int[]{sumOfEven, sumOfOdd};
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine().replaceAll("\\[|\\]","");
        if (input.isEmpty()) { // Handle empty input case
            System.out.println("[0, 0]");
            return;
        }
        String[] splitted_input = input.split(", ");
        int[] integers = new int[splitted_input.length];

        for (int i = 0; i < splitted_input.length; i++) {
            integers[i] = Integer.parseInt(splitted_input[i]);
        }
        int[] sumEvenOdd = new SumAndOdd().sumEvenOdd(integers);
        System.out.println("[" + sumEvenOdd[0] + ", " + sumEvenOdd[1] + "]");
    }
}