import java.util.*;

public class twoD_transpose {
    public int[][] transpose(int[][] array) {
        // Handle empty array
        if (array.length == 0) {
            return new int[0][0];
        }

        // Handle array with empty rows
        if (array[0].length == 0) {
            return new int[0][0];
        }

        int rows = array.length;
        int cols = array[0].length;

        // Create a new  array for the transpose
        int[][] transposedArray = new int[cols][rows];

        // Fill the transposed array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transposedArray[j][i] = array[i][j];
            }
        }

        return transposedArray;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine().trim();

        // Special case for empty matrix [[]]
        if (input.equals("[[]]")) {
            System.out.println("[[]]");
            return;
        }

        // Remove the outer brackets
        input = input.substring(2, input.length() - 2);

        // Handle empty input
        if (input.isEmpty()) {
            System.out.println("[[]]");
            return;
        }

        // Split by "], [" to get individual rows
        String[] rowStrings = input.split("\\], \\[");

        // Parse the rows into a matrix
        int[][] matrix = new int[rowStrings.length][];
        for (int i = 0; i < rowStrings.length; i++) {
            String[] elements = rowStrings[i].split(", ");

            matrix[i] = new int[elements.length];
            for (int j = 0; j < elements.length; j++) {
                matrix[i][j] = Integer.parseInt(elements[j]);
            }
        }

        // Transpose the matrix
        int[][] transposedMatrix = new twoD_transpose().transpose(matrix);

        // Print the transposed matrix
        System.out.print("[");
        for (int i = 0; i < transposedMatrix.length; i++) {
            System.out.print("[");
            for (int j = 0; j < transposedMatrix[i].length; j++) {
                System.out.print(transposedMatrix[i][j]);
                if (j < transposedMatrix[i].length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.print("]");
            if (i < transposedMatrix.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }
}