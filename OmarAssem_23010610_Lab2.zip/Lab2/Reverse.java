import java.io.*;
import java.util.*;

public class Reverse {
    public int[] reverse(int[] array) {
        int length_of_array = array.length;
        int[] reversed_array=new int[length_of_array];
        for(int i=0;i<length_of_array;i++) {
            reversed_array[i]=array[array.length-1-i];
        }
        return reversed_array;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String sin = sc.nextLine().replaceAll("\\[|\\]", "");
        String[] s = sin.split(", ");
        int[] arr = new int[s.length];

        if (s.length == 1 && s[0].isEmpty()) {
            arr = new int[]{};
        } else {
            for (int i = 0; i < s.length; ++i)
                arr[i] = Integer.parseInt(s[i]);
        }

        int[] res = new Reverse().reverse(arr);
        System.out.print("[");
        for (int i = 0; i < res.length; ++i) {
            System.out.print(res[i]);
            if (i != res.length - 1)
                System.out.print(", ");
        }
        System.out.print("]");
    }
}
