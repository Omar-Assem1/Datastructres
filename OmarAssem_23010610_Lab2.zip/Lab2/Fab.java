import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Fab {
    public int fibonacci(int n) {
        int[] fabonacci = new int[n + 1];
    if (n == 0) {
        return 0;
    }
    fabonacci[0] = 1;
    fabonacci[1] = 1;
    for (int i = 2; i <= n; i++) {
        fabonacci[i]=fabonacci[i-1]+fabonacci[i-2];
    }
    return fabonacci[n-1];
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        n = n-1;
        int fab = new Fab().fibonacci(n);
        System.out.println(fab);
    }
}