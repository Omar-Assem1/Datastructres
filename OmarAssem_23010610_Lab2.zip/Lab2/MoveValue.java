import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class MoveValue {
    public int[] moveValue(int[] array, int value) {
        int counter = 0;
        int x = 0;
        for (int i = 0; i < array.length; ++i) {
            if (array[i] == value) {
                counter++;
                continue;
            }

            array[x] = array[i];
            x++;
        }
        int y = counter;
        for (int i = 0; i < counter; ++i) {
            array[array.length - i-1] = value;
        }
        return array;
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s = in.nextLine().replaceAll("\\[|\\]","");
        if (s.isEmpty()) {
            System.out.println("[]");
            return;
        }
        String[] tokens = s.split(", ");
        int[] array = new int[tokens.length];
        if (array.length == 0) {
            System.out.println("[]");
        }
        for (int i = 0; i < tokens.length; i++) {
            array[i] = Integer.parseInt(tokens[i]);
        }
        int value = in.nextInt();
        int[] res = new MoveValue().moveValue(array, value);
        System.out.print("[");
        for (int i = 0; i < res.length; ++i) {
            System.out.print(res[i]);
            if (i != res.length - 1)
                System.out.print(", ");
        }
        System.out.print("]");
        return;
    }
}