import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

/**
 * Interface for an Expression Evaluator that supports converting infix to postfix
 * and evaluating postfix expressions.
 */
interface IExpressionEvaluator {

    /**
     * Takes a symbolic/numeric infix expression as input and converts it to
     * postfix notation.
     *
     * @param expression infix expression
     * @return postfix expression
     */
    public String infixToPostfix(String expression);

    /**
     * Evaluates a postfix numeric expression, with a single space separator.
     *
     * @param expression postfix expression
     * @return the evaluated value
     */
    public int evaluate(String expression);
}

/**
 * Class that implements expression evaluation using a stack and double linked list.
 * This class can convert infix expressions to postfix notation and evaluate them.
 * It also supports variables (a, b, c) which can be set and used in expressions.
 */
public class Evaluator implements IExpressionEvaluator {

    /** Maximum number of variables that can be stored */
    private static final int MAX_VARIABLES = 26;

    /** Array to store variable names */
    private String[] variableNames;

    /** Array to store variable values */
    private int[] variableValues;

    /** Number of variables currently stored */
    private int variableCount;

    /**
     * Constructor initializes arrays to store variables and their values.
     */
    public Evaluator() {
        variableNames = new String[MAX_VARIABLES];
        variableValues = new int[MAX_VARIABLES];
        variableCount = 0;
    }

    /**
     * Converts an infix expression to postfix notation.
     * Handles operator precedence, parentheses, and unary operators.
     *
     * @param expression infix expression to convert
     * @return the equivalent postfix expression
     * @throws RuntimeException if the expression is invalid
     */
    @Override
    public String infixToPostfix(String expression) {
        expression = preprocessExpression(expression);
        if (expression.isEmpty()) {
            throw new RuntimeException();
        }

        MyStack stack = new MyStack();
        StringBuilder postfix = new StringBuilder();
        StringBuilder currentOperand = new StringBuilder();
        boolean isNegatedExpression = expression.startsWith("(0-(");

        for (int i = 0; i < expression.length(); i++) {
            char c = expression.charAt(i);

            if (Character.isLetterOrDigit(c)) {
                currentOperand.append(c);
            } else {
                if (currentOperand.length() > 0) {
                    if (!(isNegatedExpression && currentOperand.toString().equals("0"))) {
                        postfix.append(currentOperand).append(" ");
                    }
                    currentOperand.setLength(0);
                }

                if (c == '(') {
                    stack.push(c);
                } else if (c == ')') {
                    while (!stack.isEmpty() && !stack.peek().equals('(')) {
                        postfix.append(stack.pop()).append(" ");
                    }
                    if (stack.isEmpty()) {
                        throw new RuntimeException();
                    }
                    stack.pop();
                    if (isNegatedExpression && i == expression.length() - 1) {
                        postfix.append("- ");
                    }
                } else if (isOperator(c)) {
                    if (isNegatedExpression && c == '-' && i == 2) {
                        continue;
                    }
                    while (!stack.isEmpty() && isOperator((Character) stack.peek()) &&
                            hasHigherPrecedence((Character) stack.peek(), c)) {
                        postfix.append(stack.pop()).append(" ");
                    }
                    stack.push(c);
                } else {
                    throw new RuntimeException();
                }
            }
        }

        if (currentOperand.length() > 0) {
            if (!(isNegatedExpression && currentOperand.toString().equals("0"))) {
                postfix.append(currentOperand).append(" ");
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek().equals('(')) {
                throw new RuntimeException();
            }
            postfix.append(stack.pop()).append(" ");
        }

        return postfix.toString().trim().replaceAll("\\s+", "");
    }

    /**
     * Preprocesses the input expression to handle spaces and unary minus signs.
     * Simplifies various syntactic elements and transforms them to a standard form.
     *
     * @param expression input expression
     * @return processed expression ready for conversion
     */
    private String preprocessExpression(String expression) {
        if (expression == null || expression.trim().isEmpty()) {
            return "";
        }
        expression = expression.replaceAll("\\s+", "");

        // Handle simple unary cases like +a or -a
        if (expression.matches("[+-][a-c]")) {
            char operator = expression.charAt(0);
            char variable = expression.charAt(1);
            return String.valueOf(variable) + operator;
        }

        // Handle unary minus before parentheses, e.g., -(a+b)
        if (expression.startsWith("-(") && expression.endsWith(")")) {
            return "(0" + expression + ")";
        }

        // Check for valid characters
        if (!expression.matches("[a-c0-9+\\-*/^()]+")) {
            return "";
        }

        StringBuilder processed = new StringBuilder();
        boolean expectOperand = true;

        for (int i = 0; i < expression.length(); i++) {
            char current = expression.charAt(i);

            if (current == '-') {
                int minusCount = 1;
                while (i + 1 < expression.length() && expression.charAt(i + 1) == '-') {
                    minusCount++;
                    i++;
                }

                if (minusCount % 2 == 0) {
                    if (!expectOperand) {
                        processed.append('+');
                    }
                    expectOperand = true;
                } else {
                    if (expectOperand) {
                        if (i + 1 < expression.length() && Character.isLetterOrDigit(expression.charAt(i + 1))) {
                            processed.append(expression.charAt(i + 1)).append('-');
                            i++;
                            expectOperand = false;
                        } else {
                            return "";
                        }
                    } else {
                        processed.append('-');
                        expectOperand = true;
                    }
                }
            } else if (current == '+') {
                processed.append('+');
                expectOperand = true;
            } else {
                processed.append(current);
                expectOperand = (current == '(' || isOperator(current));
            }
        }

        return processed.toString();
    }

    /**
     * Evaluates a postfix expression and returns the result.
     * Uses a stack-based algorithm to process the expression.
     *
     * @param expression postfix expression to evaluate
     * @return result of the evaluation
     * @throws RuntimeException if the expression is invalid
     * @throws ArithmeticException if division by zero occurs
     */
    @Override
    public int evaluate(String expression) {
        if (expression == null || expression.trim().isEmpty()) {
            throw new RuntimeException();
        }

        MyStack stack = new MyStack();
        String[] tokens = expression.trim().split("\\s+");

        for (String token : tokens) {
            if (token.isEmpty()) {
                continue;
            }

            if (isOperator(token.charAt(0))) {
                if (token.equals("-") && stack.size() == 1) {
                    // Unary minus: negate the top operand
                    int operand = (Integer) stack.pop();
                    stack.push(-operand);
                } else if (token.equals("+") && stack.size() == 1) {
                    // Unary plus: keep the operand as is
                    continue;
                } else {
                    if (stack.size() < 2) {
                        throw new RuntimeException();
                    }

                    int operand2 = (Integer) stack.pop();
                    int operand1 = (Integer) stack.pop();
                    int result;

                    switch (token.charAt(0)) {
                        case '+': result = operand1 + operand2; break;
                        case '-': result = operand1 - operand2; break;
                        case '*': result = operand1 * operand2; break;
                        case '/':
                            if (operand2 == 0) {
                                throw new ArithmeticException();
                            }
                            result = operand1 / operand2;
                            break;
                        case '^': result = (int) Math.pow(operand1, operand2); break;
                        default: throw new RuntimeException();
                    }

                    stack.push(result);
                }
            } else {
                processToken(token, stack);
            }
        }

        if (stack.size() != 1) {
            throw new RuntimeException();
        }

        return (Integer) stack.pop();
    }

    /**
     * Processes a single token (variable or number) from the expression.
     * Pushes the appropriate value onto the stack.
     *
     * @param token the token to process
     * @param stack the stack to push the value onto
     * @throws RuntimeException if the token is an undefined variable or invalid number
     */
    private void processToken(String token, MyStack stack) {
        int value;
        if (Character.isLetter(token.charAt(0))) {
            value = getVariableValue(token);
            if (value == Integer.MIN_VALUE) {
                throw new RuntimeException();
            }
        } else {
            try {
                value = Integer.parseInt(token);
            } catch (NumberFormatException e) {
                throw new RuntimeException();
            }
        }
        stack.push(value);
    }

    /**
     * Checks if a character is a valid operator.
     *
     * @param c character to check
     * @return true if the character is an operator, false otherwise
     */
    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
    }

    /**
     * Determines if the first operator has higher or equal precedence than the second.
     *
     * @param op1 first operator
     * @param op2 second operator
     * @return true if op1 has higher or equal precedence than op2
     */
    private boolean hasHigherPrecedence(char op1, char op2) {
        return getPrecedence(op1) >= getPrecedence(op2);
    }

    /**
     * Gets the precedence value of an operator.
     * Higher value means higher precedence.
     *
     * @param operator the operator to check
     * @return precedence value (0-3)
     */
    private int getPrecedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
                return 3;
            default:
                return 0;
        }
    }

    /**
     * Sets a variable's value.
     * If the variable already exists, updates its value.
     * Otherwise, adds a new variable if there's space available.
     *
     * @param name  variable name
     * @param value variable value
     */
    public void setVariable(String name, int value) {
        for (int i = 0; i < variableCount; i++) {
            if (variableNames[i].equals(name)) {
                variableValues[i] = value;
                return;
            }
        }

        if (variableCount < MAX_VARIABLES) {
            variableNames[variableCount] = name;
            variableValues[variableCount] = value;
            variableCount++;
        }
    }

    /**
     * Gets the value of a variable by name.
     *
     * @param name variable name
     * @return variable value, or Integer.MIN_VALUE if the variable is not defined
     */
    private int getVariableValue(String name) {
        for (int i = 0; i < variableCount; i++) {
            if (variableNames[i].equals(name)) {
                return variableValues[i];
            }
        }
        return Integer.MIN_VALUE;
    }

    /**
     * Main method to run the expression evaluator from the command line.
     * Reads input expressions and variable assignments, then evaluates the expression.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Evaluator evaluator = new Evaluator();

        try {
            String infixExpression = scanner.nextLine().trim();
            if (infixExpression.isEmpty() || !isValidExpression(infixExpression)) {
                System.out.println("Error");
                return;
            }

            // Check if expression ends with an operator
            if (isOperator(infixExpression.charAt(infixExpression.length() - 1))) {
                System.out.println("Error");
                return;
            }

            // Read variable assignments if any
            for (char c : new char[]{'a', 'b', 'c'}) {
                if (scanner.hasNextLine()) {
                    String line = scanner.nextLine().trim();
                    if (!line.isEmpty() && line.matches("[abc]=-?\\d+")) {
                        int value = Integer.parseInt(line.substring(2));
                        evaluator.setVariable(String.valueOf(c), value);
                    }
                }
            }

            // Convert to postfix and evaluate
            String postfixExpression = evaluator.infixToPostfix(infixExpression);
            String internalPostfix = postfixExpression.replaceAll("(?<=.)(?=.)", " ");
            int result = evaluator.evaluate(internalPostfix);

            // Print the results
            System.out.println(postfixExpression);
            System.out.println(result);

        } catch (Exception e) {
            System.out.println("Error");
        } finally {
            scanner.close();
        }
    }

    /**
     * Checks if an expression contains only valid characters.
     *
     * @param expr expression to validate
     * @return true if the expression contains only valid characters
     */
    private static boolean isValidExpression(String expr) {
        return expr.matches("[a-c0-9+\\-*/^()]+");
    }
}

/**
 * Interface defining stack operations.
 */
interface IStack {
    /**
     * Removes and returns the top element of the stack.
     *
     * @return the top element of the stack
     * @throws EmptyStackException if the stack is empty
     */
    Object pop();

    /**
     * Returns the top element of the stack without removing it.
     *
     * @return the top element of the stack
     * @throws EmptyStackException if the stack is empty
     */
    Object peek();

    /**
     * Pushes an element onto the top of the stack.
     *
     * @param element the element to push
     */
    void push(Object element);

    /**
     * Checks if the stack is empty.
     *
     * @return true if the stack is empty, false otherwise
     */
    boolean isEmpty();

    /**
     * Returns the number of elements in the stack.
     *
     * @return the number of elements in the stack
     */
    int size();
}

/**
 * Stack implementation using DoubleLinkedList.
 * This class provides LIFO (Last-In-First-Out) functionality
 * required for expression evaluation.
 */
class MyStack implements IStack {
    /** The linked list used to store stack elements */
    private DoubleLinkedList list;

    /**
     * Constructs an empty stack.
     */
    public MyStack() {
        list = new DoubleLinkedList();
    }

    /**
     * Pushes an element onto the top of the stack.
     *
     * @param element the element to push
     */
    @Override
    public void push(Object element) {
        list.add(0, element);
    }

    /**
     * Removes and returns the top element of the stack.
     *
     * @return the top element of the stack
     * @throws EmptyStackException if the stack is empty
     */
    @Override
    public Object pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        Object top = list.get(0);
        list.remove(0);
        return top;
    }

    /**
     * Returns the top element of the stack without removing it.
     *
     * @return the top element of the stack
     * @throws EmptyStackException if the stack is empty
     */
    @Override
    public Object peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return list.get(0);
    }

    /**
     * Checks if the stack is empty.
     *
     * @return true if the stack is empty, false otherwise
     */
    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Returns the number of elements in the stack.
     *
     * @return the number of elements in the stack
     */
    @Override
    public int size() {
        return list.size();
    }
}

/**
 * Interface defining linked list operations.
 */
interface ILinkedList {
    /**
     * Inserts the specified element at the specified position in this list.
     *
     * @param index position where the element should be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException if index is out of range
     */
    void add(int index, Object element);

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element element to be appended
     */
    void add(Object element);

    /**
     * Returns the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position
     * @throws IndexOutOfBoundsException if index is out of range
     */
    Object get(int index);

    /**
     * Replaces the element at the specified position in this list with the specified element.
     *
     * @param index index of the element to replace
     * @param element element to be stored at the specified position
     * @throws IndexOutOfBoundsException if index is out of range
     */
    void set(int index, Object element);

    /**
     * Removes all elements from this list.
     */
    void clear();

    /**
     * Returns true if this list contains no elements.
     *
     * @return true if this list contains no elements
     */
    boolean isEmpty();

    /**
     * Removes the element at the specified position in this list.
     *
     * @param index the index of the element to be removed
     * @throws IndexOutOfBoundsException if index is out of range
     */
    void remove(int index);

    /**
     * Returns the number of elements in this list.
     *
     * @return the number of elements in this list
     */
    int size();

    /**
     * Returns a view of the portion of this list between the specified fromIndex and toIndex.
     *
     * @param fromIndex low endpoint (inclusive) of the subList
     * @param toIndex high endpoint (inclusive) of the subList
     * @return a view of the specified range within this list
     * @throws IndexOutOfBoundsException if fromIndex or toIndex are out of range
     */
    ILinkedList sublist(int fromIndex, int toIndex);

    /**
     * Returns true if this list contains the specified element.
     *
     * @param o element whose presence in this list is to be tested
     * @return true if this list contains the specified element
     */
    boolean contains(Object o);
}

/**
 * Double linked list implementation.
 * Provides a two-way linked list with nodes containing references to both
 * the next and previous nodes in the list.
 */
class DoubleLinkedList implements ILinkedList {
    /**
     * Node class for the linked list.
     * Contains data and references to next and previous nodes.
     */
    private class Node {
        /** Data stored in this node */
        Object data;
        /** Reference to the next node in the list */
        Node next;
        /** Reference to the previous node in the list */
        Node prev;

        /**
         * Constructs a node with the given data.
         *
         * @param d the data to store in this node
         */
        Node(Object d) {
            data = d;
            next = null;
            prev = null;
        }
    }

    /** Sentinel node at the beginning of the list */
    private Node header;
    /** Sentinel node at the end of the list */
    private Node tailer;
    /** Number of elements in the list */
    private int size;

    /**
     * Constructs an empty list.
     * Initializes the sentinel nodes and connects them.
     */
    public DoubleLinkedList() {
        header = new Node(null);
        tailer = new Node(null);
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    /**
     * Inserts the specified element at the specified position in this list.
     *
     * @param index position where the element should be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public void add(int index, Object element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        Node newNode = new Node(element);
        Node temp = header;
        for (int i = 0; i < index; i++) temp = temp.next;
        Node succ = temp.next;
        newNode.next = succ;
        newNode.prev = temp;
        temp.next = newNode;
        succ.prev = newNode;
        size++;
    }

    /**
     * Appends the specified element to the end of this list.
     *
     * @param element element to be appended
     */
    @Override
    public void add(Object element) {
        add(size, element);
    }

    /**
     * Returns the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public Object get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) iter = iter.next;
        return iter.data;
    }

    /**
     * Replaces the element at the specified position in this list with the specified element.
     *
     * @param index index of the element to replace
     * @param element element to be stored at the specified position
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public void set(int index, Object element) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) iter = iter.next;
        iter.data = element;
    }

    /**
     * Removes all elements from this list.
     * Resets the list to its initial empty state.
     */
    @Override
    public void clear() {
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    /**
     * Returns true if this list contains no elements.
     *
     * @return true if this list contains no elements
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns the number of elements in this list.
     *
     * @return the number of elements in this list
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * Returns a view of the portion of this list between the specified fromIndex and toIndex.
     *
     * @param fromIndex low endpoint (inclusive) of the subList
     * @param toIndex high endpoint (inclusive) of the subList
     * @return a view of the specified range within this list
     * @throws IndexOutOfBoundsException if fromIndex or toIndex are out of range
     */
    @Override
    public ILinkedList sublist(int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex >= size || fromIndex > toIndex)
            throw new IndexOutOfBoundsException();
        DoubleLinkedList list = new DoubleLinkedList();
        Node iter = header.next;
        for (int i = 0; i < fromIndex; i++) iter = iter.next;
        for (int i = fromIndex; i <= toIndex; i++) {
            list.add(iter.data);
            iter = iter.next;
        }
        return list;
    }

    /**
     * Returns true if this list contains the specified element.
     *
     * @param o element whose presence in this list is to be tested
     * @return true if this list contains the specified element
     */
    @Override
    public boolean contains(Object o) {
        Node iter = header.next;
        while (iter != tailer) {
            if (iter.data.equals(o)) return true;
            iter = iter.next;
        }
        return false;
    }

    /**
     * Removes the element at the specified position in this list.
     *
     * @param index the index of the element to be removed
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public void remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) iter = iter.next;
        iter.prev.next = iter.next;
        iter.next.prev = iter.prev;
        size--;
    }
}