import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

/**
 * Interface defining the standard operations of a stack data structure.
 */
interface IStack {

    /**
     * Removes the element at the top of stack and returns that element.
     * @return top of stack element
     * @throws EmptyStackException if the stack is empty
     */
    public Object pop();

    /**
     * Gets the element at the top of stack without removing it.
     * @return top of stack element
     * @throws EmptyStackException if the stack is empty
     */
    public Object peek();

    /**
     * Pushes an item onto the top of this stack.
     * @param element the object to be pushed onto the stack
     */
    public void push(Object element);

    /**
     * Tests if this stack is empty.
     * @return true if stack is empty, false otherwise
     */
    public boolean isEmpty();

    /**
     * Returns the number of elements in the stack.
     * @return the number of elements in the stack
     */
    public int size();
}

/**
 * Implementation of the IStack interface using a doubly linked list.
 * This class provides a stack data structure with standard operations.
 */
public class MyStack implements IStack {
    /** The underlying data structure used to store stack elements */
    private DoubleLinkedList list;

    /**
     * Constructs an empty stack.
     */
    public MyStack() {
        list = new DoubleLinkedList();
    }

    /**
     * {@inheritDoc}
     * Pushes element to the beginning of the list (top of stack).
     */
    @Override
    public void push(Object element) {
        list.add(0, element);
    }

    /**
     * {@inheritDoc}
     * Removes and returns the element at the beginning of the list (top of stack).
     */
    @Override
    public Object pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        Object top = list.get(0);

        list.remove(0);
        return top;
    }

    /**
     * {@inheritDoc}
     * Returns the element at the beginning of the list (top of stack).
     */
    @Override
    public Object peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return list.get(0);
    }

    /**
     * {@inheritDoc}
     * Delegates to the underlying list's isEmpty method.
     */
    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * {@inheritDoc}
     * Delegates to the underlying list's size method.
     */
    @Override
    public int size() {
        return list.size();
    }

    /**
     * Returns a string representation of the stack.
     * @return a string representation of the stack
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(list.get(i));
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * Main method to demonstrate stack operations.
     * Accepts input from standard input to perform stack operations.
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MyStack stack = new MyStack();

        try {
            String input = scanner.nextLine().trim();
            if (!input.equals("[]")) {
                String[] elements = input.substring(1, input.length() - 1).split(", ");
                for (int i = elements.length - 1; i >= 0; i--) {
                    try {
                        stack.push(Integer.parseInt(elements[i]));
                    } catch (NumberFormatException e) {
                        stack.push(elements[i]);
                    }
                }
            }
            String operation = scanner.nextLine().trim();

            switch (operation) {
                case "push":
                    if (scanner.hasNextLine()) {
                        try {
                            Object element = parseInput(scanner.nextLine().trim());
                            stack.push(element);
                            System.out.println(stack);
                        } catch (Exception e) {
                            System.out.println("Error");
                        }
                    }
                    break;

                case "pop":
                    try {
                        stack.pop();
                        System.out.println(stack);
                    } catch (EmptyStackException e) {
                        System.out.println("Error");
                    }
                    break;

                case "peek":
                    try {
                        System.out.println(stack.peek());
                    } catch (EmptyStackException e) {
                        System.out.println("Error");
                    }
                    break;

                case "isEmpty":
                    System.out.println(stack.isEmpty() ? "True" : "False");
                    break;

                case "size":
                    System.out.println(stack.size());
                    break;

                default:
                    System.out.println("Error");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error");
        } finally {
            scanner.close();
        }
    }

    /**
     * Parses input string to an appropriate object.
     * Tries to parse as Integer first, falls back to String if not possible.
     * @param input the string to parse
     * @return the parsed object (Integer or String)
     */
    private static Object parseInput(String input) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return input;
        }
    }
}

/**
 * Interface defining the standard operations of a linked list data structure.
 */
interface ILinkedList {
    /**
     * Inserts the specified element at the specified position in this list.
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    void add(int index, Object element);

    /**
     * Appends the specified element to the end of this list.
     * @param element element to be appended to this list
     */
    void add(Object element);

    /**
     * Returns the element at the specified position in this list.
     * @param index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    Object get(int index);

    /**
     * Replaces the element at the specified position in this list with the specified element.
     * @param index index of the element to replace
     * @param element element to be stored at the specified position
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    void set(int index, Object element);

    /**
     * Removes all of the elements from this list.
     */
    void clear();

    /**
     * Returns true if this list contains no elements.
     * @return true if this list contains no elements
     */
    boolean isEmpty();

    /**
     * Removes the element at the specified position in this list.
     * @param index the index of the element to be removed
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    void remove(int index);

    /**
     * Returns the number of elements in this list.
     * @return the number of elements in this list
     */
    int size();

    /**
     * Returns a view of the portion of this list between fromIndex, inclusive, and toIndex, inclusive.
     * @param fromIndex low endpoint (inclusive) of the subList
     * @param toIndex high endpoint (inclusive) of the subList
     * @return a view of the specified range within this list
     * @throws IndexOutOfBoundsException if fromIndex or toIndex is out of range
     */
    ILinkedList sublist(int fromIndex, int toIndex);

    /**
     * Returns true if this list contains the specified element.
     * @param o element whose presence in this list is to be tested
     * @return true if this list contains the specified element
     */
    boolean contains(Object o);
}

/**
 * Implementation of the ILinkedList interface as a doubly linked list.
 * This class provides a list data structure with nodes containing references to both
 * the next and previous nodes in the list.
 */
class DoubleLinkedList implements ILinkedList {
    /**
     * Node class for the doubly linked list.
     * Each node contains data and references to the next and previous nodes.
     */
    private class Node {
        /** The data stored in this node */
        Object data;
        /** Reference to the next node in the list */
        Node next;
        /** Reference to the previous node in the list */
        Node prev;

        /**
         * Constructs a new node with the given data.
         * @param d the data to be stored in the node
         */
        Node(Object d) {
            this.data = d;
            this.next = null;
            this.prev = null;
        }
    }

    /** Sentinel node marking the beginning of the list */
    private Node header;
    /** Sentinel node marking the end of the list */
    private Node tailer;
    /** Number of elements in the list */
    private int size;

    /**
     * Constructs an empty doubly linked list.
     * Initializes the header and tailer sentinel nodes.
     */
    public DoubleLinkedList() {
        header = new Node(null);
        tailer = new Node(null);
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void add(int index, Object element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        Node newNode = new Node(element);
        if (index == 0) {
            Node temp = header.next;
            newNode.next = temp;
            newNode.prev = header;
            temp.prev = newNode;
            header.next = newNode;
        } else if (index == size) {
            Node temp = tailer.prev;
            temp.next = newNode;
            newNode.prev = temp;
            newNode.next = tailer;
            tailer.prev = newNode;
        } else {
            Node iter = header.next;
            for (int i = 0; i < index - 1; i++) {
                iter = iter.next;
            }
            Node temp = iter.next;
            iter.next = newNode;
            temp.prev = newNode;
            newNode.next = temp;
            newNode.prev = iter;
        }
        size++;
    }

    /**
     * {@inheritDoc}
     * Adds the element at the end of the list.
     */
    @Override
    public void add(Object element) {
        add(size, element);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        return iter.data;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void set(int index, Object element) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        iter.data = element;
    }

    /**
     * {@inheritDoc}
     * Resets the list to its empty state.
     */
    @Override
    public void clear() {
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return size;
    }

    /**
     * {@inheritDoc}
     * Creates a new list containing elements from fromIndex to toIndex (inclusive).
     */
    @Override
    public ILinkedList sublist(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= size) throw new IndexOutOfBoundsException();
        if (toIndex < 0 || toIndex >= size) throw new IndexOutOfBoundsException();
        if (fromIndex > toIndex) throw new IndexOutOfBoundsException();

        DoubleLinkedList newList = new DoubleLinkedList();
        Node iter = header.next;

        for (int i = 0; i < fromIndex; i++) {
            iter = iter.next;
        }
        for (int i = fromIndex; i <= toIndex; i++) {
            newList.add(iter.data);
            iter = iter.next;
        }
        return newList;
    }

    /**
     * {@inheritDoc}
     * Checks if the list contains the specified object.
     */
    @Override
    public boolean contains(Object o) {
        Node iter = header.next;
        while (iter != tailer) {
            if (iter.data != null && iter.data.equals(o)) {
                return true;
            }
            iter = iter.next;
        }
        return false;
    }

    /**
     * {@inheritDoc}
     * Removes the node at the specified index.
     */
    @Override
    public void remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        if (index == 0) {
            Node temp1 = header.next;
            Node temp2 = temp1.next;
            header.next = temp2;
            temp2.prev = header;
            temp1.next = null;
            temp1.prev = null;
        } else if (index == size-1) {
            Node temp1 = tailer.prev;
            Node temp2 = temp1.prev;
            temp2.next = tailer;
            tailer.prev = temp2;
            temp1.next = null;
            temp1.prev = null;
        } else {
            Node iter = header.next;
            for (int i = 0; i < index; i++) {
                iter = iter.next;
            }
            Node temp1 = iter.prev;
            Node temp2 = iter.next;
            temp1.next = temp2;
            temp2.prev = temp1;
            iter.next = null;
            iter.prev = null;
        }
        size--;
    }
}