import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;


interface IPlayersFinder {
    /**
     * Search for players locations at the given photo
     * @param photo
     *      Two dimension array of photo contents
     *   Will contain between 1 and 50 elements, inclusive
     * @param team
     * Identifier of the team
     * @param threshold
     * Minimum area for an element
     * Will be between 1 and 10000, inclusive
     * @return
     * Array of players locations of the given team
     */
    Point[] findPlayers(String[] photo, int team, int threshold);
}

public class PlayersFinder implements IPlayersFinder {

    @Override
    public Point[] findPlayers(String[] photo, int team, int threshold) {
        if (photo == null || photo.length == 0 || photo[0].isEmpty()) {
            return new Point[0];
        }

        char teamChar = Character.forDigit(team, 10);
        int rows = photo.length;
        int cols = photo[0].length();
        boolean[][] visited = new boolean[rows][cols];
        List<Point> players = new ArrayList<>();

        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (photo[r].charAt(c) == teamChar && !visited[r][c]) {
                    int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE;
                    int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
                    int area = 0;

                    Queue<int[]> queue = new LinkedList<>();
                    queue.add(new int[]{r, c});
                    visited[r][c] = true;

                    while (!queue.isEmpty()) {
                        int[] current = queue.poll();
                        int y = current[0], x = current[1];

                        minX = Math.min(minX, x * 2);
                        minY = Math.min(minY, y * 2);
                        maxX = Math.max(maxX, (x * 2) + 2);
                        maxY = Math.max(maxY, (y * 2) + 2);
                        area += 4;

                        for (int[] dir : directions) {
                            int newY = y + dir[0];
                            int newX = x + dir[1];

                            if (newY >= 0 && newY < rows && newX >= 0 && newX < cols && !visited[newY][newX] && photo[newY].charAt(newX) == teamChar) {
                                visited[newY][newX] = true;
                                queue.add(new int[]{newY, newX});
                            }
                        }
                    }

                    if (area >= threshold) {
                        int centerX = (minX + maxX) / 2;
                        int centerY = (minY + maxY) / 2;
                        players.add(new Point(centerX, centerY));
                    }
                }
            }
        }

        players.sort(Comparator.comparingInt((Point p) -> p.x).thenComparingInt(p -> p.y));

        return players.toArray(new Point[0]);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] dimensions = scanner.nextLine().trim().split(",");
        int rows = Integer.parseInt(dimensions[0].trim());
        int cols = Integer.parseInt(dimensions[1].trim());

        String[] photo = new String[rows];
        for (int i = 0; i < rows; i++) {
            photo[i] = scanner.nextLine().trim();
            if (photo[i].length() != cols) {
                throw new IllegalArgumentException("Expected width: " + cols);
            }
        }

        int team = scanner.nextInt();
        int threshold = scanner.nextInt();

        PlayersFinder finder = new PlayersFinder();
        Point[] players = finder.findPlayers(photo, team, threshold);

        System.out.print("[");
        for (int i = 0; i < players.length; i++) {
            System.out.print("(" + players[i].x + ", " + players[i].y + ")");
            if (i < players.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");

        scanner.close();
    }
}