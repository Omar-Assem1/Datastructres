import java.util.Scanner;

interface ILinkedList {
    void add(int index, Object element);
    void add(Object element);
    Object get(int index);
    void set(int index, Object element);
    void clear();
    boolean isEmpty();
    void remove(int index);
    int size();
    ILinkedList sublist(int fromIndex, int toIndex);
    boolean contains(Object o);
}

class DoubleLinkedList implements ILinkedList {
    private class Node {
        Object data;
        Node next;
        Node prev;

        Node(Object d) {
            this.data = d;
            this.next = null;
            this.prev = null;
        }
    }

    private Node header;
    private Node tailer;
    private int size;

    public DoubleLinkedList() {
        header = new Node(null);
        tailer = new Node(null);
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    @Override
    public void add(int index, Object element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        Node newNode = new Node(element);
        if (index == 0) {
            Node temp = header.next;
            newNode.next = temp;
            newNode.prev = header;
            temp.prev = newNode;
            header.next = newNode;
        } else if (index == size) {
            Node temp = tailer.prev;
            temp.next = newNode;
            newNode.prev = temp;
            newNode.next = tailer;
            tailer.prev = newNode;
        } else {
            Node iter = header.next;
            for (int i = 0; i < index - 1; i++) {
                iter = iter.next;
            }
            Node temp = iter.next;
            iter.next = newNode;
            temp.prev = newNode;
            newNode.next = temp;
            newNode.prev = iter;
        }
        size++;
    }

    @Override
    public void add(Object element) {
        add(size, element);
    }

    @Override
    public Object get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        return iter.data;
    }

    @Override
    public void set(int index, Object element) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = header.next;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        iter.data = element;
    }

    @Override
    public void clear() {
        header.next = tailer;
        tailer.prev = header;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public ILinkedList sublist(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= size) throw new IndexOutOfBoundsException();
        if (toIndex < 0 || toIndex >= size) throw new IndexOutOfBoundsException();
        if (fromIndex > toIndex) throw new IndexOutOfBoundsException();

        DoubleLinkedList newList = new DoubleLinkedList();
        Node iter = header.next;

        for (int i = 0; i < fromIndex; i++) {
            iter = iter.next;
        }
        for (int i = fromIndex; i <= toIndex; i++) {
            newList.add(iter.data);
            iter = iter.next;
        }
        return newList;
    }

    @Override
    public boolean contains(Object o) {
        Node iter = header.next;
        while (iter != tailer) {
            if (iter.data.equals(o)) {
                return true;
            }
            iter = iter.next;
        }
        return false;
    }

    @Override
    public void remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        if (index == 0) {
            Node temp1 = header.next;
            Node temp2 = temp1.next;
            header.next = temp2;
            temp2.prev = header;
            temp1.next = null;
            temp1.prev = null;
        } else if (index == size-1) {
            Node temp1 = tailer.prev;
            Node temp2 = temp1.prev;
            temp2.next = tailer;
            tailer.prev = temp2;
            temp1.next = null;
            temp1.prev = null;
        } else {
            Node iter = header.next;
            for (int i = 0; i < index; i++) {
                iter = iter.next;
            }
            Node temp1 = iter.next;
            Node temp2 = iter.prev;
            temp1.prev = temp2;
            temp2.next = temp1;
            iter.next = null;
            iter.prev = null;
        }
        size--;
    }
}

interface IPolynomialSolver {
    void setPolynomial(char poly, int[] terms);
    String print(char poly);
    void clearPolynomial(char poly);
    float evaluatePolynomial(char poly, float value);
    int[][] add(char poly1, char poly2);
    int[][] subtract(char poly1, char poly2);
    int[][] multiply(char poly1, char poly2);
}

public class PolynomialSolver implements IPolynomialSolver {
    private DoubleLinkedList[] polynomials;
    private DoubleLinkedList R;

    public PolynomialSolver() {
        polynomials = new DoubleLinkedList[3]; // A=0, B=1, C=2
        R = new DoubleLinkedList();
    }

    private static class Term {
        int coefficient;
        int exponent;

        Term(int coeff, int exp) {
            this.coefficient = coeff;
            this.exponent = exp;
        }
    }

    @Override
    public void setPolynomial(char poly, int[] terms) {
        int index = getIndex(poly);
        if (index == -1) throw new RuntimeException();
        if (terms.length == 0) throw new RuntimeException(); // Add this check for empty input

        DoubleLinkedList list = new DoubleLinkedList();
        for (int i = 0; i < terms.length; i++) {
            int exponent = terms.length - 1 - i;
            if (terms[i] != 0) {
                list.add(new Term(terms[i], exponent));
            }
        }
        polynomials[index] = list;
    }

    @Override
    public String print(char poly) {
        DoubleLinkedList list = getList(poly);
        if (list == null|| list.isEmpty()) throw new RuntimeException();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            Term term = (Term) list.get(i);
            int coeff = term.coefficient;
            int exp = term.exponent;

            if (i > 0) {
                if (coeff > 0) {
                    sb.append("+");
                    if (coeff != 1) sb.append(coeff);
                } else {
                    if (coeff == -1) sb.append("-1");
                    else sb.append(coeff);
                }
            } else {
                if (coeff == -1 && exp != 0) sb.append("-1");
                else if (coeff != 1 || exp == 0) sb.append(coeff);
            }

            if (exp > 1) {
                sb.append("x^").append(exp);
            } else if (exp == 1) {
                sb.append("x");
            }
        }
        return sb.toString();
    }

    @Override
    public void clearPolynomial(char poly) {
        if (poly == 'R') {
            R.clear();
        } else {
            int index = getIndex(poly);
            if (index == -1) throw new RuntimeException();
            polynomials[index] = null;
        }

    }

    @Override
    public float evaluatePolynomial(char poly, float value) {
        DoubleLinkedList list = getList(poly);
        if (list == null || list.isEmpty()) throw new RuntimeException();

        float result = 0;
        for (int i = 0; i < list.size(); i++) {
            Term term = (Term) list.get(i);
            result += term.coefficient * Math.pow(value, term.exponent);
        }
        return result;
    }

    @Override
    public int[][] add(char poly1, char poly2) {
        DoubleLinkedList list1 = getList(poly1);
        DoubleLinkedList list2 = getList(poly2);
        if (list1 == null || list2 == null || list1.isEmpty() ||list2.isEmpty()) throw new RuntimeException();

        R = addPolynomials(list1, list2);
        return getTerms(R);
    }

    @Override
    public int[][] subtract(char poly1, char poly2) {
        DoubleLinkedList list1 = getList(poly1);
        DoubleLinkedList list2 = getList(poly2);
        if (list1 == null || list2 == null || list1.isEmpty() ||list2.isEmpty()) throw new RuntimeException();

        R = subtractPolynomials(list1, list2);
        return getTerms(R);
    }

    @Override
    public int[][] multiply(char poly1, char poly2) {
        DoubleLinkedList list1 = getList(poly1);
        DoubleLinkedList list2 = getList(poly2);
        if (list1 == null || list2 == null || list1.isEmpty() ||list2.isEmpty()) throw new RuntimeException();

        R = multiplyPolynomials(list1, list2);
        return getTerms(R);
    }

    private DoubleLinkedList getList(char poly) {
        if (poly == 'R') return R;
        int index = getIndex(poly);
        if (index == -1)
            throw new RuntimeException();
        return polynomials[index];
    }

    private int getIndex(char poly) {
        switch (poly) {
            case 'A': return 0;
            case 'B': return 1;
            case 'C': return 2;
            default: throw new IllegalArgumentException();
        }
    }

    private DoubleLinkedList addPolynomials(DoubleLinkedList p1, DoubleLinkedList p2) {
        DoubleLinkedList result = new DoubleLinkedList();
        int i = 0, j = 0;

        while (i < p1.size() && j < p2.size()) {
            Term term1 = (Term) p1.get(i);
            Term term2 = (Term) p2.get(j);

            if (term1.exponent > term2.exponent) {
                result.add(new Term(term1.coefficient, term1.exponent));
                i++;
            } else if (term1.exponent < term2.exponent) {
                result.add(new Term(term2.coefficient, term2.exponent));
                j++;
            } else {
                int sum = term1.coefficient + term2.coefficient;
                if (sum != 0) {
                    result.add(new Term(sum, term1.exponent));
                }
                i++;
                j++;
            }
        }

        while (i < p1.size()) {
            Term term = (Term) p1.get(i++);
            result.add(new Term(term.coefficient, term.exponent));
        }

        while (j < p2.size()) {
            Term term = (Term) p2.get(j++);
            result.add(new Term(term.coefficient, term.exponent));
        }

        return result;
    }

    private DoubleLinkedList subtractPolynomials(DoubleLinkedList p1, DoubleLinkedList p2) {
        DoubleLinkedList result = new DoubleLinkedList();
        int i = 0, j = 0;

        while (i < p1.size() && j < p2.size()) {
            Term term1 = (Term) p1.get(i);
            Term term2 = (Term) p2.get(j);

            if (term1.exponent > term2.exponent) {
                result.add(new Term(term1.coefficient, term1.exponent));
                i++;
            } else if (term1.exponent < term2.exponent) {
                result.add(new Term(-term2.coefficient, term2.exponent));
                j++;
            } else {
                int diff = term1.coefficient - term2.coefficient;
                if (diff != 0) {
                    result.add(new Term(diff, term1.exponent));
                }
                i++;
                j++;
            }
        }

        while (i < p1.size()) {
            Term term = (Term) p1.get(i++);
            result.add(new Term(term.coefficient, term.exponent));
        }

        while (j < p2.size()) {
            Term term = (Term) p2.get(j++);
            result.add(new Term(-term.coefficient, term.exponent));
        }

        return result;
    }

    private DoubleLinkedList multiplyPolynomials(DoubleLinkedList p1, DoubleLinkedList p2) {
        DoubleLinkedList result = new DoubleLinkedList();

        for (int i = 0; i < p1.size(); i++) {
            Term term1 = (Term) p1.get(i);
            DoubleLinkedList temp = new DoubleLinkedList();

            for (int j = 0; j < p2.size(); j++) {
                Term term2 = (Term) p2.get(j);
                int coeff = term1.coefficient * term2.coefficient;
                int exp = term1.exponent + term2.exponent;
                temp.add(new Term(coeff, exp));
            }

            result = addPolynomials(result, temp);
        }

        return result;
    }

    private int[][] getTerms(DoubleLinkedList list) {
        if (list.size() == 0) return new int[2][0];

        int maxExp = ((Term) list.get(0)).exponent;
        int[] coefficients = new int[maxExp + 1];
        int[] exponents = new int[maxExp + 1];

        for (int i = 0; i < list.size(); i++) {
            Term term = (Term) list.get(i);
            coefficients[maxExp - term.exponent] = term.coefficient;
            exponents[maxExp - term.exponent] = term.exponent;
        }

        return new int[][]{coefficients, exponents};
    }

    public static void main(String[] args) {
        PolynomialSolver solver = new PolynomialSolver();
        Scanner scanner = new Scanner(System.in);

        while (scanner.hasNextLine()) {
            try {
                String command = scanner.nextLine().trim();
                if (command.isEmpty()) {
                    throw new Exception();
                }
                switch (command) {
                    case "set":
                        char poly = scanner.nextLine().trim().charAt(0);
                        String input = scanner.nextLine().trim();
                        if (!input.startsWith("[") || !input.endsWith("]")) {
                            System.out.println();
                            continue;
                        }
                        int[] terms = parseInput(input);
                        solver.setPolynomial(poly, terms);
                        break;

                    case "print":
                        poly = scanner.nextLine().trim().charAt(0);
                        if (poly == 'R') {
                            if (solver.R.isEmpty()) {
                                throw new IllegalArgumentException();
                            } else {
                                System.out.println(solver.print(poly));
                            }
                        } else {
                            int index = solver.getIndex(poly);
                            if (index == -1 || solver.polynomials[index] == null) {
                                throw new IllegalArgumentException();
                            } else {
                                System.out.println(solver.print(poly));
                            }
                        }
                        break;

                    case "add":
                        char poly1 = scanner.nextLine().trim().charAt(0);
                        char poly2 = scanner.nextLine().trim().charAt(0);
                        if ((poly1 == 'R' && solver.R.isEmpty()) ||
                                (poly2 == 'R' && solver.R.isEmpty()) ||
                                (poly1 != 'R' && solver.getIndex(poly1) == -1) ||
                                (poly2 != 'R' && solver.getIndex(poly2) == -1)) {
                            throw new IllegalArgumentException();
                        } else {
                            solver.add(poly1, poly2);
                            System.out.println(solver.print('R'));
                        }

                        break;

                    case "sub":
                        poly1 = scanner.nextLine().trim().charAt(0);
                        poly2 = scanner.nextLine().trim().charAt(0);
                        if ((poly1 == 'R' && solver.R.isEmpty()) ||
                                (poly2 == 'R' && solver.R.isEmpty()) ||
                                (poly1 != 'R' && solver.getIndex(poly1) == -1) ||
                                (poly2 != 'R' && solver.getIndex(poly2) == -1)) {
                            throw new IllegalArgumentException();
                        } else {
                            solver.subtract(poly1, poly2);
                            System.out.println(solver.print('R'));
                        }
                        break;

                    case "mult":
                        poly1 = scanner.nextLine().trim().charAt(0);
                        poly2 = scanner.nextLine().trim().charAt(0);
                        if ((poly1 == 'R' && solver.R.isEmpty()) ||
                                (poly2 == 'R' && solver.R.isEmpty()) ||
                                (poly1 != 'R' && solver.getIndex(poly1) == -1) ||
                                (poly2 != 'R' && solver.getIndex(poly2) == -1)) {
                            throw new IllegalArgumentException();
                        } else {
                            solver.multiply(poly1, poly2);
                            System.out.println(solver.print('R'));
                        }

                        break;

                    case "eval":
                        poly = scanner.nextLine().trim().charAt(0);
                        float value = Float.parseFloat(scanner.nextLine().trim());
                        if ((poly == 'R' && solver.R.isEmpty()) ||
                                (poly != 'R' && solver.getIndex(poly) == -1)) {
                            throw new IllegalArgumentException();
                        } else {
                            System.out.println((int)solver.evaluatePolynomial(poly, value));
                        }
                        break;

                    case "clear":
                        poly = scanner.nextLine().trim().charAt(0);
                        solver.clearPolynomial(poly);
                        System.out.println("[]");
                        break;

                    default:
                        throw new IllegalArgumentException();
                        // Skip any remaining input for this command
                }
            } catch (Exception e) {
                System.out.println("Error");
                // Clear the buffer in case of error
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    if (line.trim().isEmpty()) break;
                }
            }
        }
        scanner.close();
    }

    private static int[] parseInput(String input) {
        if (input.equals("[]")) return new int[0];

        String[] parts = input.substring(1, input.length() - 1).split(",");
        int[] coefficients = new int[parts.length];

        for (int i = 0; i < parts.length; i++) {
            coefficients[i] = Integer.parseInt(parts[i].trim());
        }

        return coefficients;
    }
}