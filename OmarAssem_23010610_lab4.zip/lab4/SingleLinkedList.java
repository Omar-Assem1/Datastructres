import java.util.Scanner;

interface ILinkedList {
    void add(int index, Object element);
    void add(Object element);
    Object get(int index);
    void set(int index, Object element);
    void clear();
    boolean isEmpty();
    void remove(int index);
    int size();
    ILinkedList sublist(int fromIndex, int toIndex);
    boolean contains(Object o);
}

public class SingleLinkedList implements ILinkedList {
    private class Node {
        Object data;
        Node next;

        Node(Object d) {
            this.data = d;
            this.next = null;
        }
    }

    private Node head;
    private int size;

    public SingleLinkedList() {
        head = null;
        size = 0;
    }

    @Override
    public void add(int index, Object element) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException();
        Node newNode = new Node(element);
        if (index == 0) {
            newNode.next = head;
            head = newNode;
        } else {
            Node iter = head;
            for (int i = 0; i < index - 1; i++) {
                iter = iter.next;
            }
            newNode.next = iter.next;
            iter.next = newNode;
        }
        size++;
    }

    @Override
    public void add(Object element) {
        add(size, element);
    }

    @Override
    public Object get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = head;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        return iter.data;
    }

    @Override
    public void set(int index, Object element) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        Node iter = head;
        for (int i = 0; i < index; i++) {
            iter = iter.next;
        }
        iter.data = element;
    }

    @Override
    public void clear() {
        head = null;
        size = 0;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public ILinkedList sublist(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= size) throw new IndexOutOfBoundsException();
        if (toIndex < 0 || toIndex >= size) throw new IndexOutOfBoundsException();
        if (fromIndex > toIndex) throw new IndexOutOfBoundsException();

        SingleLinkedList newList = new SingleLinkedList();
        Node iter = head;

        for (int i = 0; i < fromIndex; i++) {
            iter = iter.next;
        }
        for (int i = fromIndex; i <= toIndex; i++) {
            newList.add(iter.data);
            iter = iter.next;
        }
        return newList;
    }

    @Override
    public boolean contains(Object o) {
        Node iter = head;
        while (iter != null) {
            if (iter.data.equals(o)) {
                return true;
            }
            iter = iter.next;
        }
        return false;
    }

    @Override
    public void remove(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException();
        if (index == 0) {
            head = head.next;
        } else {
            Node iter = head;
            for (int i = 0; i < index - 1; i++) {
                iter = iter.next;
            }
            iter.next = iter.next.next;
        }
        size--;
    }

    private static String listToString(SingleLinkedList list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(list.get(i));
        }
        sb.append("]");
        return sb.toString();
    }

    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();
        Scanner sc = new Scanner(System.in);

        try {
            // Read initial list
            String listInput = sc.nextLine().trim();
            if (!listInput.equals("[]")) {
                String[] elements = listInput.substring(1, listInput.length() - 1).split(", ");
                for (String element : elements) {
                    try {
                        list.add(Integer.parseInt(element));
                    } catch (NumberFormatException e) {
                        list.add(element);
                    }
                }
            }

            // Read operation
            String operation = sc.nextLine().trim();

            switch (operation) {
                case "add":
                    try {
                        Object element = parseInput(sc.nextLine().trim());
                        list.add(element);
                        System.out.println(listToString(list));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "addToIndex":
                    try {
                        int index = Integer.parseInt(sc.nextLine().trim());
                        Object elem = parseInput(sc.nextLine().trim());
                        list.add(index, elem);
                        System.out.println(listToString(list));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "isEmpty":
                    System.out.println(list.isEmpty() ? "True" : "False");
                    break;

                case "set":
                    try {
                        int setIndex = Integer.parseInt(sc.nextLine().trim());
                        Object setElem = parseInput(sc.nextLine().trim());
                        list.set(setIndex, setElem);
                        System.out.println(listToString(list));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "get":
                    try {
                        int getIndex = Integer.parseInt(sc.nextLine().trim());
                        System.out.println(list.get(getIndex));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "contains":
                    try {
                        Object containsElem = parseInput(sc.nextLine().trim());
                        System.out.println(list.contains(containsElem) ? "True" : "False");
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "sublist":
                    try {
                        int fromIndex = Integer.parseInt(sc.nextLine().trim());
                        int toIndex = Integer.parseInt(sc.nextLine().trim());
                        SingleLinkedList sublist = (SingleLinkedList) list.sublist(fromIndex, toIndex);
                        System.out.println(listToString(sublist));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "clear":
                    list.clear();
                    System.out.println("[]");
                    break;

                case "remove":
                    try {
                        int removeIndex = Integer.parseInt(sc.nextLine().trim());
                        list.remove(removeIndex);
                        System.out.println(listToString(list));
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "size":
                    System.out.println(list.size());
                    break;

                default:
                    System.out.println("Error");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error");
        } finally {
            sc.close();
        }
    }

    private static Object parseInput(String input) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return input;
        }
    }
}