package interfaces;

public interface IArrayBased { }
