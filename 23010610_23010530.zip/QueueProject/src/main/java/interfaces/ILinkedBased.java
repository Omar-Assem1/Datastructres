package interfaces;

public interface ILinkedBased { }
