package tester;

import arraybased.ArrayQueue;
import linkedbased.LinkedListQueue;
import interfaces.IQueue;
import java.util.Scanner;
import java.util.NoSuchElementException;

public class QueueTester {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read input once
        String inputLine = scanner.nextLine().trim();
        String command = scanner.nextLine().trim();
        String value = null;
        if (command.equals("enqueue")) {
            value = scanner.nextLine().trim();
        }

        // Array-based queue
        System.out.println("Array-based Queue:");
        processQueue(new ArrayQueue(300), inputLine, command, value);

        // Linked-based queue
        System.out.println("\nLinked-based Queue:");
        processQueue(new LinkedListQueue(), inputLine, command, value);

        scanner.close();
    }

    private static void processQueue(IQueue queue, String inputLine, String command, String value) {
        try {
            // Parse initial elements
            inputLine = inputLine.replaceAll("[\\[\\]]", "");
            String[] elements = inputLine.split(",");
            
            for (int i = elements.length - 1; i >= 0; i--) {
                String e = elements[i].trim();
                if (!e.isEmpty()) {
                    try {
                        queue.enqueue(Integer.parseInt(e));
                    } catch (NumberFormatException ex) {
                        queue.enqueue(e);
                    }
                }
            }

            // Execute command
            switch (command) {
                case "enqueue":
                    try {
                        if (queue instanceof ArrayQueue) {
                            queue.enqueue(Integer.parseInt(value));
                        } else {
                            Object element = parseInput(value);
                            queue.enqueue(element);
                        }
                        System.out.println(queue);
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "dequeue":
                    try {
                        queue.dequeue();
                        System.out.println(queue);
                    } catch (Exception e) {
                        System.out.println("Error");
                    }
                    break;

                case "size":
                    System.out.println(queue.size());
                    break;

                case "isEmpty":
                    System.out.println(queue.isEmpty() ? "True" : "False");
                    break;

                default:
                    System.out.println("Error");
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
    }

    private static Object parseInput(String input) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return input;
        }
    }
}
